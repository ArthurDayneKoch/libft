#include "libft.h"

int main()
{
  //ft_putstr("Print it dear");
  //ft_putendl("Print it dear");
  //ft_putnbr(500);
  //int fd;

  //fd = open("testfile", O_RDWR);
  //ft_putendl_fd("hello", fd);
  //ft_putnbr_fd(1000, fd);
  /*int rez;
  rez = tolower("xsddsdsd");
  ft_putnbr(rez);
  int rez1 = ft_tolower("xsddsd");
  ft_putnbr(rez1);*/
  /*int rez;
  rez = toupper('1');
  ft_putnbr(rez);
  int rez1 = ft_toupper('1');
  ft_putnbr(rez1);*/
  /*int rez;
  rez = isprint(' ');
  ft_putnbr(rez);
  int rez1 = ft_isprint(' ');
  ft_putnbr(rez1);*/
  int rez;
  rez = isascii(40);
  ft_putnbr(rez);
  int rez1 = ft_isascii(40);
  ft_putnbr(rez1);
}
