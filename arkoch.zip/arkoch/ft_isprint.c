#include "libft.h"

int ft_isprint(int c)
{
  return ((c > 31 && c < 127) ? 1 : 0);
}
